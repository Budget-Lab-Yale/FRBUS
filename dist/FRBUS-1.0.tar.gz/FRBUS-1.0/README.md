# YBL-FRBUS-Extensions
This module provides helper functions for the Yale Budget Lab's use of FRBUS.
